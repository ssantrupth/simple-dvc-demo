from setuptools import setup, find_packages

setup(
    name="src",
    version="0.0.1",
    description="it's a wine Q package",
    author="ssantrupth",
    packages=find_packages(),
    license="MIT"
)

